
Partial Class ProductDetailReport
    Inherits System.Web.UI.Page

End Class
