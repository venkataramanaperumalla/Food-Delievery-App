
Partial Class About_Us
    Inherits System.Web.UI.Page

End Class
