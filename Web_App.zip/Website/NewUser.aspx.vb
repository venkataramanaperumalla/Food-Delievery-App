
Partial Class NewUser
    Inherits System.Web.UI.Page

End Class
